import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, precision_score, recall_score

# Bước 1: Đọc dữ liệu từ tệp CSV
data = pd.read_csv('datacum.csv', header=None)

# Đặt tên cho các cột
data.columns = ['Mã số mẫu', 'Loại', 'Độ dày hạch', 'Sự đồng nhất của kích thước tế bào',
                'Tính đồng nhất của hình dạng tế bào', 'Độ kết dính lề - biên',
                'Kích thước tế bào biểu mô đơn', 'Phần nhân ngoài', 'Chất nhiễm sắc thể',
                'Nhân trong thường', 'Vỏ']

# Bước 2: Chia dữ liệu thành tập train và test
# Chọn 80 mẫu lành tính và 40 mẫu ác tính làm tập test
benign_data = data[data['Loại'] == 2]
malignant_data = data[data['Loại'] == 4]

test_benign = benign_data.sample(n=80, random_state=42)
test_malignant = malignant_data.sample(n=40, random_state=42)

test_data = pd.concat([test_benign, test_malignant])

# Phần còn lại làm dữ liệu training
train_data = data.drop(test_data.index)

# Tách dữ liệu X (biến độc lập) và y (nhãn phân loại)
X_train = train_data.iloc[:, 2:]  # Bỏ cột mã số mẫu và loại
y_train = train_data['Loại']

X_test = test_data.iloc[:, 2:]    # Bỏ cột mã số mẫu và loại
y_test = test_data['Loại']

# Bước 3: Huấn luyện mô hình Naive Bayes
model = GaussianNB()
model.fit(X_train, y_train)

# Dự đoán trên tập test
y_pred = model.predict(X_test)

# Bước 4: Đánh giá mô hình
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, pos_label=4)  # pos_label=4 cho ác tính
recall = recall_score(y_test, y_pred, pos_label=4)

# Hiển thị kết quả
print(f'Accuracy: {accuracy * 100:.2f}%')
print(f'Precision: {precision * 100:.2f}%')
print(f'Recall: {recall * 100:.2f}%')
